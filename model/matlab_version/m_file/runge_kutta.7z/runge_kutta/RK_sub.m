function dy = RK_sub(x,y)

dy = y - 2 * x / y;
end